package com.example.practice.test1;

public abstract class AbstractExample {

	public abstract void method1();
	
	public void method2() {
		//......
		//......
	}
	
}
