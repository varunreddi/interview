package com.example.practice.model;

public class Check {
	public static void main(String[] args) {
		StudentClass sc = new StudentClass();
		System.out.println(sc.d);
	}
}
