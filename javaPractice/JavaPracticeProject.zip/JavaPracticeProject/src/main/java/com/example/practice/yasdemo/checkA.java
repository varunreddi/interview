package com.example.practice.yasdemo;

public class checkA {
	public checkA() {
		
		System.out.println("A:constructor");
	}
	{
		System.out.println("A:instance");
	}
	public void m1() {
		System.out.println("A:m1");
	}

}
