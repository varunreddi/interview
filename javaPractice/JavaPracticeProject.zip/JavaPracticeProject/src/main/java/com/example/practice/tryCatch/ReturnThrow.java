package com.example.practice.tryCatch;

class Mythread extends Thread{
	
	
	@Override
	public void run() {
		System.out.println();
	}
}

public class ReturnThrow {

	public static void main(String[] args) {
		System.out.println("hello");
	}

}
