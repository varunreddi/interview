package com.example.practice.innerclasses;
/*
class Outer {
	private int a = 10;
	private int b = 20;

	class Inner {
		int a = 100;
		int b = 200;

		void m1(int a, int b) {
			System.out.println(a + b); // local variables
			System.out.println(this.a + this.b); // Inner class variables
			System.out.println(Outer.this.a + Outer.this.b); // outer class variables
		}
	};
};

public class InnerClasses {

	public static void main(String[] args) {
		new Outer().new Inner().m1(1000, 2000);
	}

}
*/