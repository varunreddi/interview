package com.example.practice.normal;

public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int sum = 0;
				
		for(int x=0;x<=10;x++)
			sum += x;
		
		//System.out.println(" Sum for 0 to "+x);
		System.out.println(" = " +sum);

	}

}
