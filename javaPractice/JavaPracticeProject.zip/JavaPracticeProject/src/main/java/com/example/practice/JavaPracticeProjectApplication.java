package com.example.practice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaPracticeProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaPracticeProjectApplication.class, args);
	}

}

