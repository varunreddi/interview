package com.example.practice.test;

import com.example.practice.yasdemo.checkA;

public class Test extends checkA {

}
