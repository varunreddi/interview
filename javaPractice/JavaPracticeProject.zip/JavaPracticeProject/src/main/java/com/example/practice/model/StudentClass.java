package com.example.practice.model;

public class StudentClass {
	
	private int a=1;
	public int b=2;
	protected int c=3;
	int d=4;
	
	public int getA() {
		return a;
	}
	public int getB() {
		return b;
	}
	public int getC() {
		return c;
	}
	public int getD() {
		return d;
	}
	
	

}
