package com.example.practice.calculations;

public class StringDivide {
	
	String s = "abc123#678xyz";
	
	

}
