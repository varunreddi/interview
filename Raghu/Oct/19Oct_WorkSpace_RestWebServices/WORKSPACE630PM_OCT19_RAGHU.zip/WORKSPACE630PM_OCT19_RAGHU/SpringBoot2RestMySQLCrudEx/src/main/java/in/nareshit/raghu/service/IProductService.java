package in.nareshit.raghu.service;

import java.util.List;

import in.nareshit.raghu.entity.Product;

public interface IProductService {

	Integer saveProduct(Product p);
	Product findOneProduct(Integer id);
	List<Product> findAllProducts();
	void deleteProduct(Integer id);
	void updateProduct(Product p);
	void modifyCodeById(String code,Integer id);
}
