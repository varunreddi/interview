package in.nareshit.raghu.rest;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.nareshit.raghu.model.Export;
import in.nareshit.raghu.model.Processed;

@RestController
@RequestMapping("/test")
public class InOutRestcontroller {

	@PostMapping("/ob")
	public Export getExpProcess(@RequestBody Processed processed) {
		Export exp = new Export();
		exp.setId(processed.getCode().length());
		exp.setMode(processed.getModel().toUpperCase());
		exp.setStatus(processed.getStatus());
		return exp;
	}
}
