package in.nareshit.raghu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBoot2WebMvcControllerTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBoot2WebMvcControllerTestApplication.class, args);
	}

}
