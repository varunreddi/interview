package in.nareshit.raghu.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/books")
public class BookController {
	
	//........books/auths?author
	@GetMapping("/auths")
	public String getBookAuthorDetails(
			@RequestParam("author") List<String> authors,
			Model model
			)
	{
		System.out.println(authors);
		model.addAttribute("sf1", authors);
		return "BookSearchPage";
	}

	//..../books/view?bid=10&bcode=AA&bcost=96.0
	
	@GetMapping("/view")
	public String getBookDetails(
			@RequestParam("bid") Integer bid,
			@RequestParam("bcode") String bcode,
			@RequestParam("bcost") Double bcost,
			Model model
			)
	{
		System.out.println(bid+"-"+bcode+"-"+bcost);
		model.addAttribute("sf1", bid+"-"+bcode+"-"+bcost);
		return "BookSearchPage";
	}

	//..../books/find?bid=10

	@GetMapping("/find")
	public String searchBookById(
			//@RequestParam("bid") int id,
			//@RequestParam(value = "bid", required = false) Integer id,
			@RequestParam(value = "bid", required = false , defaultValue = "-1") int id,
			Model model
			)
	{
		System.out.println("Data is => " + id);
		model.addAttribute("sf1", id);
		return "BookSearchPage";
	}


	//..../books/search?book=ABC

	@GetMapping("/search")
	public String searchBookByName(
			//@RequestParam("book") String bookName,
			//@RequestParam(value = "book", required = false) String bookName,
			@RequestParam(value = "book", required = false, defaultValue = "AA") String bookName,
			Model model
			)
	{
		System.out.println("DATA IS => " + bookName );
		model.addAttribute("sf1", bookName);
		return "BookSearchPage";
	}
}
