package in.nareshit.raghu.runner;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import in.nareshit.raghu.model.Student;
import in.nareshit.raghu.repo.StudentRepository;

@Component
public class DataTestRunner implements CommandLineRunner {

	@Autowired
	private StudentRepository repo;

	public void run(String... args) throws Exception {
		repo.save(new Student(10,"A",2.2)); //INSERT..
		repo.save(new Student(11,"B",3.2)); //INSERT..
		repo.save(new Student(12,"C",4.3)); //INSERT..
		repo.save(new Student(12,"D",4.5)); //UPDATE..

		
		repo.saveAll(
				Arrays.asList(
						new Student(13,"E",5.5),
						new Student(14,"F",6.5),
						new Student(15,"F",8.5)
						)
				);

		System.out.println("--------------------------------");
		List<Student> list =  repo.findAll();

		//for each
		for(Student s:list ) {
			System.out.println(s);
		}/*
		System.out.println("************");
		//JDK 1.8 -- Lambda Expression
		list.forEach((ob)->System.out.println(ob));

		System.out.println("************");
		//JDK 1.8 -- Method Reference
		list.forEach(System.out::println);

		System.out.println("************");
		//JDK 1.8 -- Java Stream API
		Set<String> names= 
				list.stream()
				.map(ob->ob.getStdName())
				.sorted()
				.collect(Collectors.toSet());
		
		names.forEach(System.out::println);
		*/
		
		Optional<Student> opt = repo.findById(103);
		if(opt.isPresent()) {
			Student s = opt.get();
			System.out.println(s);
		} else {
			System.out.println("No data exist");
		}
		System.out.println("----------------------");
		//boolean exist = repo.existsById(12);
		boolean exist = repo.existsById(120);
		System.out.println("Is ID#12 row exist?" + exist);
		
		System.out.println("------------------------");
		repo.deleteById(12);
		repo.deleteAll();
		System.out.println("DONE");
	}

}
