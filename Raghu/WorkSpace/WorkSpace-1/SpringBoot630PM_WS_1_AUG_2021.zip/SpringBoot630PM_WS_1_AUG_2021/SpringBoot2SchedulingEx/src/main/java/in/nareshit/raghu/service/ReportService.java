package in.nareshit.raghu.service;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class ReportService {

	private static int count = 0;
	private SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss");
	

	@Scheduled(initialDelay = 5000, fixedRate =  5000)
	public void generateReport() 
			throws InterruptedException 
	{
		//DB logics, web app report generation..
		System.out.println(" START " + (++count) + " - "+ sdf.format(new Date()));
		Thread.sleep(3000); // sec 
		System.out.println(" END " + count + " - "+ sdf.format(new Date()));

	}


}
