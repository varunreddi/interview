package in.nareshit.raghu.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import in.nareshit.raghu.model.PanCard;
import in.nareshit.raghu.model.Person;
import in.nareshit.raghu.repo.PersonRepositor;

@Component
public class DataInsertRunner implements CommandLineRunner {

	@Autowired
	private PersonRepositor prepo;
	
	public void run(String... args) throws Exception {
		PanCard p1 = new PanCard(550, "ABC", "K");
		PanCard p2 = new PanCard(551, "XYZ", "R");
		
		Person per1 = new Person(10, "A", "M", p1);
		Person per2 = new Person(11, "B", "F", p2);
		
		prepo.save(per1);
		prepo.save(per2);
		
		
	}

}
