package in.nit.test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import in.nareshit.raghu.Product;

public class Test {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("AppDBOracle");
		System.out.println(factory.getClass().getName());
		EntityManager em = factory.createEntityManager();
		System.out.println(em.getClass().getName());
		EntityTransaction tx = em.getTransaction();
		try {
			tx.begin();
			//operation
			Product pob = new Product();
			pob.setProdId(101);
			pob.setProdCode("PEN");
			pob.setProdCost(200.0);
			em.persist(pob); //INSERT
			
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
			e.printStackTrace();
		}
		em.close();
		factory.close();
	}
}
