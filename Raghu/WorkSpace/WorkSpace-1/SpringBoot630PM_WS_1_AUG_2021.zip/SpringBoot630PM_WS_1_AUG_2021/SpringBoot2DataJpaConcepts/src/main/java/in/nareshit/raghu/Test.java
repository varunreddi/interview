package in.nareshit.raghu;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Test {

	public static void main(String[] args) {
		Date d = new Date();
		System.out.println(d);
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MMM/yy hh:ss");
		String dte = sdf.format(d);
		System.out.println(dte);
	}
}
