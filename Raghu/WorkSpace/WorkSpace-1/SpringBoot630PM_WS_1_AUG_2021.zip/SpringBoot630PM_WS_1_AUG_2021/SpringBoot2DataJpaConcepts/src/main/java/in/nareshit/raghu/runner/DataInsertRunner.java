package in.nareshit.raghu.runner;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import in.nareshit.raghu.model.Student;
import in.nareshit.raghu.repo.StudentRepository;

@Component
public class DataInsertRunner implements CommandLineRunner {

	@Autowired
	private StudentRepository repo;

	public void run(String... args) throws Exception {

		repo.save(
				new Student(
						101, "AA", 
						new Date(), 
						new Date(), 
						new Date())
				);
	}

}
