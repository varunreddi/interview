package in.nareshit.raghu.runner;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import in.nareshit.raghu.model.Course;
import in.nareshit.raghu.model.Student;
import in.nareshit.raghu.repo.CourseRepository;
import in.nareshit.raghu.repo.StudentRepository;

@Component
public class DataInsertRunner implements CommandLineRunner {

	@Autowired
	private CourseRepository crepo;
	
	@Autowired
	private StudentRepository srepo;
	
	public void run(String... args) throws Exception {
		//insert few courses
		Course c1 = new Course(5501, "CORE JAVA", 500.0);
		Course c2 = new Course(5502, "ADV JAVA", 600.0);
		Course c3 = new Course(5503, "HIBERNATE", 700.0);
		Course c4 = new Course(5504, "SPRING BOOT", 800.0);
		
		crepo.save(c1);
		crepo.save(c2);
		crepo.save(c3);
		crepo.save(c4);
		
		//students with courses
		Student s1 = new Student(901, "AA", "HYD", Arrays.asList(c1,c2));
		Student s2 = new Student(902, "BB", "CHN", Arrays.asList(c2,c3));
		Student s3 = new Student(903, "CC", "DHL", Arrays.asList(c4,c1));
		
		srepo.save(s1);
		srepo.save(s2);
		srepo.save(s3);
		
		System.out.println("DONE");
	}

}
