package in.nareshit.raghu.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Component;

import in.nareshit.raghu.util.MyMailUtil;

@Component
public class TestEmailRunner implements CommandLineRunner {

	@Autowired
	private MyMailUtil mailUtil;

	public void run(String... args) throws Exception {
		Resource file1 = new FileSystemResource("D:/Images/SpringBoot630PM_1407021_2.png");
		Resource file2 = new ClassPathResource("kola.jpg");
		Resource file3 = new UrlResource("https://www.realtrainings.com/assets/images/institutes/Naresh-i-Technologies-Logo.jpg");

		boolean sent = mailUtil.send(
				new String[] {  //to
						"nitsample123@gmail.com",
						"javabyraghu@gmail.com"
				}, 
				/*new String[] {  //cc
						"vikashjava8@gmail.com",
						"parag.varu@gmail.com",
						"mahato.jayanta114@gmail.com"
				}, 
				new String[] { //bcc
						"sethisritam1234@gmail.com",
						"preddy7111@gmail.com",
						"ashishjsr07@gmail.com",
						"jagannivasac@gmail.com"

				},*/ 
				"TEST SUB",  //subject
				"<html><body><h1>Hello</h1><b>abcd</b><i>IJKL</i></body></html>", //text as HTML
				new Resource[] {file1,file2,file3} // multiple attachments
				);
		if(sent) 
			System.out.println("SUCCESS");
		else
			System.out.println("FAILED");
	}

}
