package in.nareshit.raghu.util;

import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

@Component
public class MyMailUtil {
	
	@Autowired
	private JavaMailSender mailSender;
	
	//overloaded method
	public boolean send(String to,String subject, String text) {
		return send(new String[] {to}, null, null, subject, text, null);
	}
	
	//overloaded method
	public boolean send(String[] to,String subject, String text, Resource[] files) {
		return send(to, null, null, subject, text, files);
	}

	public boolean send(
			String[] to,
			String[] cc,
			String[] bcc,
			String subject,
			String text,
			Resource[] files
			) 
	{
		boolean flag = false;

		try {
			//1. create one Empty/new MimeMessage
			MimeMessage message  = mailSender.createMimeMessage();
			
			//2. use Helper class and set details
			MimeMessageHelper  helper = new MimeMessageHelper(message, files.length>0);
			
			helper.setTo(to);
			
			if(cc!=null && cc.length>0)
				helper.setCc(cc);
			
			if(bcc!=null && bcc.length>0)
				helper.setBcc(bcc);
			
			helper.setSubject(subject);
			//helper.setText(text); //false //send as Plain Text
			helper.setText(text,true);//send as HTML 
			
			if(files.length>0) {
				//file name , resource object
				for(Resource file:files)
					helper.addAttachment(file.getFilename(), file);
			}
			
			//3. send email 
			mailSender.send(message);
			
			flag = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
}
