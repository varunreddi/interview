package in.nareshit.raghu.runner;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import in.nareshit.raghu.model.Employee;
import in.nareshit.raghu.repo.EmployeeRepository;

@Component
public class TestDataRunner implements CommandLineRunner {

	@Autowired
	private EmployeeRepository erepo;
	
	public void run(String... args) throws Exception {
		List<String> l1 = new ArrayList<>();
		l1.add("M11");
		l1.add("M22");
		l1.add("M33");
		
		Set<String> s1 = new HashSet<>();
		s1.add("P11");
		s1.add("P20");
		s1.add("P30");
		
		Map<String,String> m1 = new HashMap<>();
		m1.put("C01", "NIT");
		m1.put("C02", "ORCL");
		
		erepo.save(
				new Employee(10, "ABC", 200.0,s1,l1,m1)			
				);
		System.out.println("DONE");
	}

}
