package in.nareshit.raghu.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import in.nareshit.raghu.repo.ProductRepository;

@Component
public class FetchDataRunner implements CommandLineRunner {

	@Autowired
	private ProductRepository prepo;
	
	public void run(String... args) throws Exception {
		prepo.findById(1);
		System.out.println("DONE");
	}

}
