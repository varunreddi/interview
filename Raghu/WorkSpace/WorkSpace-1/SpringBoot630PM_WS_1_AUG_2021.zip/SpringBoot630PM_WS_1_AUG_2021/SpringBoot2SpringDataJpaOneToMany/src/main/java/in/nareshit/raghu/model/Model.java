package in.nareshit.raghu.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="model_tab")
public class Model {
	
	@Id
	@Column(name="mid")
	private Integer modId;
	@Column(name="mcode")
	private String modCode;
	@Column(name="mcost")
	private Double modCost;
}
