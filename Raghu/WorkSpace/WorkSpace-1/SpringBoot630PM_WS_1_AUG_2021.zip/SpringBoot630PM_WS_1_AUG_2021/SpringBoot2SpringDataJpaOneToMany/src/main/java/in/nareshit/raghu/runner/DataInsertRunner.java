package in.nareshit.raghu.runner;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import in.nareshit.raghu.model.Model;
import in.nareshit.raghu.model.Product;
import in.nareshit.raghu.repo.ProductRepository;

@Component
public class DataInsertRunner implements CommandLineRunner {

	@Autowired
	private ProductRepository prepo;
	
	//@Autowired
	//private ModelRepository mrepo;
	
	public void run(String... args) throws Exception {
		Model m1 = new Model(10, "G12", 1200.0);
		Model m2 = new Model(11, "K14", 1500.0);
		Model m3 = new Model(12, "RT4", 2500.0);
		Model m4 = new Model(13, "MN", 8500.0);
		
		/*mrepo.save(m1);
		mrepo.save(m2);
		mrepo.save(m3);
		mrepo.save(m4);
		*/
		
		Set<Model> s1 = new HashSet<>();
		s1.add(m1);
		s1.add(m2);
		
		Product p1 = new Product(1, "A-MOB", "NIT", s1);
		Product p2 = new Product(2, "X-BED", "XYZ", Set.of(m3,m4));
		
		prepo.save(p1);
		prepo.save(p2);
		
		
	}

}
