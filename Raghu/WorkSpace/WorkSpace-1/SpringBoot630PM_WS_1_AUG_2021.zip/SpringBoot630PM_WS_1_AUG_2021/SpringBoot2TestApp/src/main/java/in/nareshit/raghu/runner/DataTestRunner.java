package in.nareshit.raghu.runner;

import java.util.Arrays;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

@Component
public class DataTestRunner implements ApplicationRunner {

	public void run(ApplicationArguments args) throws Exception {
		
		System.out.println("------------All Arguments--------------");
		System.out.println(args.getSourceArgs()); //toString
		System.out.println(Arrays.toString(args.getSourceArgs()));
		
		System.out.println("------------Option Argument key names--------------");
		System.out.println(args.getOptionNames());
		
		System.out.println("------------Option Argument exist?--------------");
		System.out.println(args.containsOption("my.app.client"));
		
		System.out.println("------------Option Argument values--------------");
		System.out.println(args.getOptionValues("my.app.client"));
		
		System.out.println("------------Nonoption Arguments--------------");
		System.out.println(args.getNonOptionArgs());
	}

}
