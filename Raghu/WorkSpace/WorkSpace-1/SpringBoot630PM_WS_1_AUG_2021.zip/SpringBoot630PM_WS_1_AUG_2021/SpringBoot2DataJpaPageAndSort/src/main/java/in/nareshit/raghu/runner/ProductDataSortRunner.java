package in.nareshit.raghu.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Order;

import in.nareshit.raghu.model.Product;
import in.nareshit.raghu.repo.ProductRepository;

//@Component
public class ProductDataSortRunner implements CommandLineRunner {

	@Autowired
	private ProductRepository repo;

	public void run(String... args) throws Exception {
		/*** SELECT * FROM  PRODUCT ORDER BY VENDOR ASC ***/
		/*
		//a. create Sort(C) object
		Sort s1 = Sort.by("vendor");

		//call findAll method with Sort object
		Iterable<Product> list = repo.findAll(s1);

		//print (JDK 5-forEach)
		for(Product p:list) {
			System.out.println(p);
		}
		 */
		/*** SELECT * FROM  PRODUCT ORDER BY VENDOR DESC ***/
		/*Sort s2 = Sort.by(Direction.DESC, "vendor");
		Iterable<Product> list = repo.findAll(s2);
		for(Product p:list) {
			System.out.println(p);
		}*/

		/*** SELECT * FROM  PRODUCT ORDER BY VENDOR ASC ,PCOST ASC ***/
		/*Sort s3 = Sort.by("vendor","pcost"); // ASC
		Iterable<Product> list = repo.findAll(s3);

		for(Product p:list) {
			System.out.println(p);
		}*/
		/*** SELECT * FROM  PRODUCT ORDER BY VENDOR DESC ,PCOST DESC ***/
		/*Sort s4 = Sort.by(Direction.DESC, "vendor","pcost"); //DESC
		Iterable<Product> list = repo.findAll(s4);

		for(Product p:list) {
			System.out.println(p);
		}*/
		/*** SELECT * FROM  PRODUCT ORDER BY VENDOR ASC ,PCOST DESC ***/
		Sort s5 = Sort.by(Order.asc("vendor"),Order.desc("pcost"));
		Iterable<Product> list = repo.findAll(s5);

		for(Product p:list) {
			System.out.println(p);
		}
		
	}

}
