package in.nareshit.raghu.runner;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import in.nareshit.raghu.model.Product;
import in.nareshit.raghu.repo.ProductRepository;

//@Component
public class ProductDataPaginationRunner implements CommandLineRunner {

	@Autowired
	private ProductRepository repo;
	
	public void run(String... args) throws Exception {
		//page num, page size
		Pageable pageable = PageRequest.of(0, 3);
		
		Page<Product> page = repo.findAll(pageable);
		
		//methods in Page
		//Content/Data
		List<Product> list = page.getContent();
		list.forEach(System.out::println);
		
		//-----------meta data---------------------
		System.out.println("---------------------------------");
		System.out.println("Is First Page => " + page.isFirst());
		System.out.println("Is Last Page => " + page.isLast());
		System.out.println("Has Next Page => " + page.hasNext());
		System.out.println("Has Previous Page => " + page.hasPrevious());
		System.out.println("Total Page => " + page.getTotalPages());
		System.out.println("Total Rows => " + page.getTotalElements());
		System.out.println("Current Page number => " + page.getNumber());
		System.out.println("Current Page Size => " + page.getSize());
	}

}
