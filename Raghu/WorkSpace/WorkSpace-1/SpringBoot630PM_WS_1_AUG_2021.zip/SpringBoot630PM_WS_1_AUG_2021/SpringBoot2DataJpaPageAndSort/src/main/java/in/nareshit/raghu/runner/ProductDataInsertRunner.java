package in.nareshit.raghu.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;

import in.nareshit.raghu.model.Product;
import in.nareshit.raghu.repo.ProductRepository;

//@Component
public class ProductDataInsertRunner implements CommandLineRunner {

	@Autowired
	private ProductRepository repo;
	
	public void run(String... args) throws Exception {
		repo.save(new Product(550, "PEN", 200.0, "NIT"));
		repo.save(new Product(551, "BOOK", 800.0, "XYZ"));
		repo.save(new Product(552, "BAT", 250.0, "NIT"));
		repo.save(new Product(553, "LAP", 1600.0, "TEST"));
		
		repo.save(new Product(554, "BOX", 210.0, "NIT"));
		repo.save(new Product(555, "MOBIL", 5800.0, "TEST"));
		repo.save(new Product(556, "MOUSE", 260.0, "NIT"));
		repo.save(new Product(557, "KEYBRD", 500.0, "XYZ"));

		repo.save(new Product(558, "TRB", 400.0, "XYZ"));
		repo.save(new Product(559, "MNO", 300.0, "NITs"));
		
	}

}
