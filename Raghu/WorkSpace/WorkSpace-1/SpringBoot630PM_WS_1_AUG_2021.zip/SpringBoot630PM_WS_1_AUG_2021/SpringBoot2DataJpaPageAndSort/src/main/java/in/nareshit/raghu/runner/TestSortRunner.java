package in.nareshit.raghu.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;
import org.springframework.stereotype.Component;

import in.nareshit.raghu.repo.ProductRepository;

@Component
public class TestSortRunner implements CommandLineRunner{

	@Autowired
	private ProductRepository repo;
	
	public void run(String... args) throws Exception {
		//select * from product order by vendor asc
		//Sort s1 = Sort.by("vendor"); //asc
		
		//select * from product order by vendor desc
		//Sort s1 = Sort.by(Direction.DESC,"vendor"); //desc

		
		//select * from product order by vendor asc, pcost asc
		//Sort s1 = Sort.by("vendor","pcost"); //asc
		
		
		//select * from product order by vendor desc, pcost desc
		//Sort s1 = Sort.by(Direction.DESC,"vendor","pcost"); //desc
		
		
		//select * from product order by vendor asc, pcost desc
		Sort s1 = Sort.by(Order.asc("vendor"),Order.desc("pcost"));

		repo.findAll(s1)
		.forEach(System.out::println);
		;
	}
}
