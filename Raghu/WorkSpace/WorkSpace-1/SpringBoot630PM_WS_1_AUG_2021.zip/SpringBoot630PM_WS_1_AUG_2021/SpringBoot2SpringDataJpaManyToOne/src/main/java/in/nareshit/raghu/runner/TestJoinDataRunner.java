package in.nareshit.raghu.runner;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import in.nareshit.raghu.repo.EmployeeRepository;

@Component
public class TestJoinDataRunner implements CommandLineRunner {

	@Autowired
	private EmployeeRepository erepo;
	
	public void run(String... args) throws Exception {
		//List<Object[]> list = erepo.getFullJoinData();
		//List<Object[]> list = erepo.getInnerJoinData();
		//List<Object[]> list = erepo.getLeftJoinData();
		//List<Object[]> list = erepo.getInnerJoinDataA(11);
		List<Object[]> list = erepo.getLeftJoinDataNonConn();
		//List<Object[]> list = erepo.getRightJoinData();
		for(Object[] ob:list) {
			System.out.println(ob[0]+"-"+ob[1]);
		}
	}

}
