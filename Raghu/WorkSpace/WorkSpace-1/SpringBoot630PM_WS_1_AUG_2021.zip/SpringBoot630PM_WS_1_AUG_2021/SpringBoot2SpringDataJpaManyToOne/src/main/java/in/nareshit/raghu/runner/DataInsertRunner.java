package in.nareshit.raghu.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;

import in.nareshit.raghu.model.Department;
import in.nareshit.raghu.model.Employee;
import in.nareshit.raghu.repo.DepartmentRepository;
import in.nareshit.raghu.repo.EmployeeRepository;

//@Component
public class DataInsertRunner implements CommandLineRunner {
	
	@Autowired
	private DepartmentRepository drepo;
	
	@Autowired
	private EmployeeRepository erepo;
	
	public void run(String... args) throws Exception {
		
		Department d1 = new Department(501, "DEV");
		Department d2 = new Department(502, "QA");
		Department d3 = new Department(503, "BA");
		Department d4 = new Department(504, "ADMIN");
		
		drepo.save(d1);
		drepo.save(d2);
		drepo.save(d3);
		drepo.save(d4);
		
		Employee e1 = new Employee(10, "SAM", null);
		Employee e2 = new Employee(11, "SYED", d1);
		Employee e3 = new Employee(12, "AJAY", null);
		Employee e4 = new Employee(13, "RAM", d3);
		
		
		erepo.save(e1);
		erepo.save(e2);
		erepo.save(e3);
		erepo.save(e4);
		
		
	}

}
