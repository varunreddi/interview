package in.nareshit.raghu.model;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component
public class EmailInfo {
	
	@Value("${mail.code}")
	private String code;
	
	@Value("${mail.host}")
	private String host;
	
	@Value("${mail.port}")
	private String port;
	
	@Value("${mail.un}")
	private String un;
	
	@Value("${mail.pwd}")
	private String pwd;
	
}
