package in.nareshit.raghu.model;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component
public class ProductInfo {
	
	@Value("${my.client.id}")
	private String clientId;
	
	@Value("${my.client.code}")
	private String clientCode;
}
