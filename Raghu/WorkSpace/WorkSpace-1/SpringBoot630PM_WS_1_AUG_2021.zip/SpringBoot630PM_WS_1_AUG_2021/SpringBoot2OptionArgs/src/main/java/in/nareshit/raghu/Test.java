package in.nareshit.raghu;

public class Test {

	public static void main(String[] args) {
		System.out.println("DONE");
		System.out.println(args[0]);//CLR
		System.out.println(System.getProperty("my.title")); //-Dmy.title=NIT
	}
}
