package in.nareshit.raghu.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import in.nareshit.raghu.model.ProductInfo;

@Component
public class TestArgsRunner implements CommandLineRunner {

	@Autowired
	private ProductInfo pob;
	
	public void run(String... args) throws Exception {
		System.out.println(pob);
	}

}
