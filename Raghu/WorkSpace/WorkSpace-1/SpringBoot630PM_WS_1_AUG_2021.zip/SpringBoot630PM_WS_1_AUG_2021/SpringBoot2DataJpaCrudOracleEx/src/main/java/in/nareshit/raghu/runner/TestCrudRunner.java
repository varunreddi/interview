package in.nareshit.raghu.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import in.nareshit.raghu.exception.ProductNotFoundException;
import in.nareshit.raghu.model.Product;
import in.nareshit.raghu.repo.ProductRepository;

@Component
public class TestCrudRunner implements CommandLineRunner {

	@Autowired
	private ProductRepository repo;

	public void run(String... args) throws Exception {
		repo.save(new Product(101, "PEN", 200.0));
		repo.save(new Product(102, "BOOK", 400.0));
		repo.save(new Product(103, "TABLE", 500.0));
		repo.save(new Product(104, "BAT", 100.0));
		/*System.out.println("--DONE-----------");
		repo.save(new Product(104, "BAT NEW", 150.0));


		repo.saveAll(
				//Arrays.asList( //JDK 1.2
				List.of( //JDK 9	
						new Product(105, "A", 900.0),
						new Product(106, "B", 800.0),
						new Product(107, "C", 700.0),
						new Product(108, "D", 600.0)
						)
				);

		Iterable<Product> itr = repo.findAll();

		//===Print data using diff core java concepts=============
		//itr.forEach(System.out::println); //using method reference
		//itr.forEach(ob -> System.out.println(ob)); //using Lambda Expression
		Iterator<Product> it = itr.iterator(); //using iterator
		while (it.hasNext()) {
			Product p =  it.next();
			System.out.println(p);
		}*/

		//Optional<Product> opt = repo.findById(101);
		/*Optional<Product> opt = repo.findById(996);
		if(opt.isPresent()) {
			Product p = opt.get();
			System.out.println(p);
		} else {
			System.out.println("No data found");
		}*/

		/*boolean exist = repo.existsById(101);
		System.out.println(exist);*/

		/*Iterable<Product> list = 
				repo.findAllById(Arrays.asList(100,101,105,120,111,174,104));
		list.forEach(System.out::println);*/

		//System.out.println("No Of Rows are: " + repo.count());

		/*repo.deleteById(1019);
		System.out.println("DELETED");*/


		repo.delete(repo.findById(1019)
				.orElseThrow(
						()->
						new ProductNotFoundException("Product is not exist")
						)
				);
	}

}
