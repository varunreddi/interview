package in.nareshit.raghu.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Table(name="prodtab")
@Entity
@AllArgsConstructor
@Data
@NoArgsConstructor
public class Product {
	
	@Column(name="pid")
	@Id
	private Integer prodId;
	
	@Column(name="pcode",length = 10) 
	private String prodCode;
	
	@Column(name="pcost")
	private Double prodCost;
	
}
