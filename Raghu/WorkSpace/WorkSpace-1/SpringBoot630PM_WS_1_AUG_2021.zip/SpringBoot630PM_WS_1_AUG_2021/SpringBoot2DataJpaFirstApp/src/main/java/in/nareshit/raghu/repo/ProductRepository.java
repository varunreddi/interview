package in.nareshit.raghu.repo;

import org.springframework.data.repository.CrudRepository;

import in.nareshit.raghu.model.Product;

public interface ProductRepository extends CrudRepository<Product, Integer>
{

}
