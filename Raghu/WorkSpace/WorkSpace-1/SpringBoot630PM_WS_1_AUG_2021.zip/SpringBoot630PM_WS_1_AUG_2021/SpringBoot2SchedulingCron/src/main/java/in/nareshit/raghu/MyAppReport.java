package in.nareshit.raghu;

import java.util.Date;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class MyAppReport {

	//@Scheduled(cron = "0 0 * * * *")
	@Scheduled(cron = "@hourly")
	public void executeRepo() {
		System.out.println("HELLO "+ new Date());
	}
	
}
