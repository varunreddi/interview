package in.nareshit.raghu.runner;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

@Component
public class DataTestRunner implements CommandLineRunner {

	public void run(String... args) throws Exception {
		StopWatch st = new StopWatch("TITLE-APP TESTING");

		st.start("TASK-ID-001");
		
		System.out.println("HELLO");
		for (int i = 0; i < 999999999; i++) {
			Math.pow(i+1*(i+1), Math.pow(i+1*(i+1), 
					Math.pow(i+1, Math.pow(i+1, i))));
		}
		Thread.sleep(2000);
		st.stop();
		

		st.start("TASK-ID-002");
		
		for (int i = 0; i < 999999999; i++) {
			Math.pow(i+1*(i+1), Math.pow(i+1*(i+1), 
					Math.pow(i+1, Math.pow(i+1, i))));
		}
		Thread.sleep(3000);
		st.stop();
		
		st.start("TASK-ID-003");
		for (int i = 0; i < 999999999; i++) {
			Math.pow(i+1*(i+1), Math.pow(i+1*(i+1), 
					Math.pow(i+1, Math.pow(i+1, i))));
		}
		System.out.println("BYE!");
		st.stop();

		System.out.println(st.prettyPrint());
		/*System.out.println(st.getTotalTimeSeconds());
		System.out.println(st.getTotalTimeMillis());
		System.out.println(st.getTotalTimeNanos());*/
	}
}
