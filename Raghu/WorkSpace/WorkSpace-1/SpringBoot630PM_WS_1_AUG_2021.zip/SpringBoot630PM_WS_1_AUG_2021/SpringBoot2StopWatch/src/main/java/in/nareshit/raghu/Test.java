package in.nareshit.raghu;

import java.util.concurrent.TimeUnit;

public class Test {

	public static void main(String[] args) {
		System.out.println(TimeUnit.MINUTES.toSeconds(3));
		System.out.println(TimeUnit.DAYS.toSeconds(3));
		System.out.println(TimeUnit.SECONDS.toNanos(1));
		System.out.println(TimeUnit.HOURS.toNanos(1));
		System.out.println(TimeUnit.HOURS.toDays(48));
	}
}
