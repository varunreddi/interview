package in.nareshit.raghu.model;

import lombok.Data;

@Data
public class LicenceInfo {

	private String provider;
	private String code;
}
