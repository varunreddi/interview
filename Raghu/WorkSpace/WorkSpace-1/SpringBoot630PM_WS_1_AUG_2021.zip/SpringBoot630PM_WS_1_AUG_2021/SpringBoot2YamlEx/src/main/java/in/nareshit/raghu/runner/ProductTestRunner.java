package in.nareshit.raghu.runner;

//ctrl+shft+O
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import in.nareshit.raghu.model.Product;

@Component
public class ProductTestRunner implements CommandLineRunner {

	@Autowired
	private Product prod;
	
	@Autowired
	private Environment env;
	
	public void run(String... args) throws Exception {
		System.out.println(prod);
		System.out.println(env.getClass().getName()); //impl class
		System.out.println(env.getProperty("my.app.pid"));
	}

}
