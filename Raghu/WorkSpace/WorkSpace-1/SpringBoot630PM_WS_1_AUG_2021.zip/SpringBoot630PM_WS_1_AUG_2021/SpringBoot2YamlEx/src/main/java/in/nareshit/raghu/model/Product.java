package in.nareshit.raghu.model;

import java.util.Properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

@ConfigurationProperties(prefix = "my.app")
@Component
@Data
public class Product {

	private Integer pid;
	private String pcode;
	private Double pcost;
	
	//private List<String> models;
	private String[] models;
	
	private Properties clients;
	//private Map<String,String> clients;
	
	private LicenceInfo lob;//HAS-A
	
}
