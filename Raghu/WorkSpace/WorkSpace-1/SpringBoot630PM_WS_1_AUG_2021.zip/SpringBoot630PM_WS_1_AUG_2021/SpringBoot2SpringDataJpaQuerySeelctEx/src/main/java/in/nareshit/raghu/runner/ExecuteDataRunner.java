package in.nareshit.raghu.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import in.nareshit.raghu.repo.StudentRepository;

@Component
public class ExecuteDataRunner implements CommandLineRunner {

	@Autowired
	private StudentRepository repo;
	
	public void run(String... args) throws Exception {
		//List<String> list = repo.getStudentNames();
		//list.forEach(System.out::println);
		
		/*
		List<Object[]> list = repo.getStudentIdAndNames();
		list
		.stream()
		.map(ob->ob[0]+"-"+ob[1])
		.forEach(System.out::println);
		*/
		
		/*List<Student> list = repo.getAllStudents();
		list.forEach(System.out::println);
		*/
		
		//repo.getStudentNamesById(11).forEach(System.out::println);
		//repo.getStudentNamesByInput(10,400.0).forEach(System.out::println);
		
		//select name where it contains one char
		//repo.getDataA("_").forEach(System.out::println);
		//select name where it contains A char
		//repo.getDataA("%A%").forEach(System.out::println);
		
		//repo.getDataB(Arrays.asList(10,12,14,18,22,96)).forEach(System.out::println);
		//repo.getDataC(10,15).forEach(System.out::println);
		//repo.getDataD().forEach(System.out::println);
		//repo.getDataE(10).forEach(System.out::println);
		
		//int count = repo.updateStudentById("NEW NAME", 11);
		int count = repo.deleteStudentByName("DUMMY");
		System.out.println(count);
	}

}
