package in.nareshit.raghu.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;

import in.nareshit.raghu.model.Student;
import in.nareshit.raghu.repo.StudentRepository;

//@Component
public class StudentDataInsertRunner implements CommandLineRunner {

	@Autowired
	private StudentRepository repo;
	
	public void run(String... args) throws Exception {
		repo.save(new Student(10,"A",2.2));
		repo.save(new Student(11,"B",3.2));
		repo.save(new Student(12,"C",4.3));
		repo.save(new Student(13,"D",5.0));
		repo.save(new Student(14,"E",4.8));
	}

}
