package in.nareshit.raghu.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class EmployeeController {

	@RequestMapping(value = {
			"/login",
			"/home"
	},method = { 
			RequestMethod.GET,
			RequestMethod.POST
	})
	public String showPageA(HttpServletRequest request) {
		System.out.println(request.getRequestURI() +"-"+request.getMethod()+" is called");
		return "EmpLogin";
	}


	/*@RequestMapping(value = "/home",method = RequestMethod.POST)//POST
	public String showPageB() {
		System.out.println("/home with POST is called");
		return "EmpDashboard";
	}*/
}
