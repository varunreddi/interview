package in.nareshit.raghu.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/std")
public class StudentController {

	@RequestMapping("/show")
	public String showStd() {
		display();
		return "StdHome";
	}
	
	public void display() {
		System.out.println("FROM DISPLAY");
	}
}
