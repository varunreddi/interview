package in.nareshit.raghu.controller;

import java.util.Arrays;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import in.nareshit.raghu.model.Employee;

@Controller
@RequestMapping("/employee")
public class EmployeeController {
	
	@GetMapping("/info")
	public String display() {
		return "EmpInfo";
	}
	

	@GetMapping("/show")
	public String showData(Model model) {
		//primitive
		model.addAttribute("eid", 101);
		model.addAttribute("ename", "ABC");
		model.addAttribute("esal", 200.0);

		//object
		model.addAttribute("eob", new Employee(990, "SAM", "DEV"));

		//collection
		model.addAttribute("list",
				Arrays.asList(
						new Employee(990, "SAM", "DEV"),
						new Employee(991, "RAM", "QA"),
						new Employee(992, "SYED", "BA"),
						new Employee(993, "AJAY", "DEV")
						)
				);


		return "EmpData";
	}
}
