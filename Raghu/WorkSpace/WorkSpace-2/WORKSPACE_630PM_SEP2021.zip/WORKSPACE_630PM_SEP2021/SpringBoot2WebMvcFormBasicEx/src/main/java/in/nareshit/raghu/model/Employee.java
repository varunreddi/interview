package in.nareshit.raghu.model;

import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Employee {

	private Integer empId;
	private String empName;
	private Double empSal;
	private String empPwd;
	private String empGen;
	private String empDept;
	private String empAddr;
	
	private List<String> empClients;
	private List<String> empSlots;
	
	private String empImg;
	private Double empAge;
	//private String empJoinDate;
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date empJoinDate;
	private String empNewDate;
	private String empColor;
}
