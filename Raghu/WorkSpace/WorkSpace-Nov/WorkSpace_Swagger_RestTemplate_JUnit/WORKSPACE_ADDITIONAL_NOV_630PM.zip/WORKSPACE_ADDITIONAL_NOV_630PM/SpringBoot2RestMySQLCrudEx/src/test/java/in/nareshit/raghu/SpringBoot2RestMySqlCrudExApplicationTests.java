package in.nareshit.raghu;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

@SpringBootTest(webEnvironment = WebEnvironment.MOCK)
@AutoConfigureMockMvc
@TestPropertySource("classpath:application-test.properties")
public class SpringBoot2RestMySqlCrudExApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@Test
	@Order(1)
	@DisplayName("CREATING ONE PRODUCT")
	public void testCreateProduct() throws Exception {
		//1. Create one HTTP REQUEST
		MockHttpServletRequestBuilder request = 
				MockMvcRequestBuilders.post("/rest/product/save")
				.contentType(MediaType.APPLICATION_JSON)
				.content("{\"prodCode\": \"PEN\", \"prodCost\": 200.0,\"prodVendor\": \"SAMPLE\"}");

		//2. execute and get result
		MvcResult result = mockMvc.perform(request).andReturn();

		//3. read response
		MockHttpServletResponse response = result.getResponse();

		//4. assert/validate it.
		assertEquals(HttpStatus.CREATED.value(), response.getStatus());
		assertNotNull(response.getContentAsString());
		if(!response.getContentAsString().contains("created")) {
			fail("May not be saved");
		}
	}

	@Test
	@Order(2)
	@DisplayName("FETCHING ALL PRODUCT")
	public void testGetAllProducts() throws Exception {
		//1. create Request object
		MockHttpServletRequestBuilder request = 
				MockMvcRequestBuilders.get("/rest/product/all");

		//2. execute and get result
		MvcResult result = mockMvc.perform(request).andReturn();

		//3. read response
		MockHttpServletResponse response = result.getResponse();

		//4 validate response
		assertEquals(HttpStatus.OK.value(), response.getStatus());
		assertNotNull(response.getContentAsString());
		assertEquals(MediaType.APPLICATION_JSON_VALUE, response.getContentType());
	}

	@Test
	@Order(3)
	@DisplayName("FETCH ONE ROW BY ID-EXISTED DATA")
	public void testFetchOneProductExist() throws Exception {
		//1. create Request object
		MockHttpServletRequestBuilder request =
				MockMvcRequestBuilders.get("/rest/product/find/{id}", 1);

		//2. execute and get result
		MvcResult result = mockMvc.perform(request).andReturn();

		//3. read response
		MockHttpServletResponse response = result.getResponse();

		//4. validate response
		assertEquals(HttpStatus.OK.value(), response.getStatus());
		assertNotNull(response.getContentAsString());
		assertEquals(MediaType.APPLICATION_JSON_VALUE, response.getContentType());

	}

	//@Disabled
	@Test
	@Order(4)
	@DisplayName("FETCH ONE ROW BY ID-NOT EXISTED")
	public void testFetchOneProductNotExist() throws Exception {
		//1. create Request object
		MockHttpServletRequestBuilder request =
				MockMvcRequestBuilders.get("/rest/product/find/{id}", 999);

		//2. execute and get result
		MvcResult result = mockMvc.perform(request).andReturn();

		//3. read response
		MockHttpServletResponse response = result.getResponse();

		//4. validate response
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getStatus());
		assertEquals(MediaType.APPLICATION_JSON_VALUE, response.getContentType());
		if(!response.getContentAsString().contains("DATA NOT FOUND")) {
			fail("MAY BE GIVEN ID EXIST!!");
		}
	}

	@Disabled
	@Test
	@Order(5)
	@DisplayName("REMOVE ONE ROW BY ID-EXISTED")
	public void testRemoveOneProductExist() throws Exception {
		//1. create Request object
		MockHttpServletRequestBuilder request =
				MockMvcRequestBuilders.delete("/rest/product/remove/{id}",1);
		//2. execute and get result
		MvcResult result = mockMvc.perform(request).andReturn();

		//3. read response
		MockHttpServletResponse response = result.getResponse();

		//4. validate response
		assertEquals(HttpStatus.OK.value(), response.getStatus());
		if(!response.getContentAsString().contains("deleted")) {
			fail("MAY BE GIVEN ID NOT EXIST!!");
		}
	}

	@Test
	@Order(6)
	@DisplayName("REMOVE ONE ROW BY ID- NOT EXISTED")
	public void testRemoveOneProductNotExist() throws Exception {
		//1. create Request object
		MockHttpServletRequestBuilder request =
				MockMvcRequestBuilders.delete("/rest/product/remove/{id}",9999);

		//2. execute and get result
		MvcResult result = mockMvc.perform(request).andReturn();

		//3. read response
		MockHttpServletResponse response = result.getResponse();

		//4. validate response
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getStatus());
		assertEquals(MediaType.APPLICATION_JSON_VALUE, response.getContentType());
		if(!response.getContentAsString().contains("DATA NOT FOUND")) {
			fail("MAY BE GIVEN ID EXIST!!");
		}
	}

	@Test
	@Order(7)
	@DisplayName("TEST UPDATE METHOD")
	public void testUpdateProduct() throws Exception {
		//1. Create one HTTP REQUEST
		MockHttpServletRequestBuilder request = 
				MockMvcRequestBuilders.put("/rest/product/modify")
				.contentType(MediaType.APPLICATION_JSON)
				.content("{\"prodId\":1,\"prodCode\": \"PEN-NEW\", \"prodCost\": 800.0,\"prodVendor\": \"SAMPLE-NIT\"}");

		//2. execute and get result
		MvcResult result = mockMvc.perform(request).andReturn();

		//3. read response
		MockHttpServletResponse response = result.getResponse();

		//4. validate response
		assertEquals(HttpStatus.OK.value(), response.getStatus());
		if(!response.getContentAsString().contains("updated")) {
			fail("MAY BE GIVEN ID NOT EXIST!!");
		}
	}
	
	/** create request, execute, read response, 
	 *  check status-500,response-JSON,
	 *  response body -- DATA NOT FOUND
	 */
	//public void testUpdateProductNotExist() throws Exception {}
	
	
	/** create request, execute, read response, 
	 *  check status-200,response-Updated,
	 */
	//public void testupdateProdCodeExist() throws Exception {}
	
	/** create request, execute, read response, 
	 *  check status-500,response-JSON,
	 *  response body -- DATA NOT FOUND
	 */
	//public void testupdateProdCodeNotExist() throws Exception {}
}
