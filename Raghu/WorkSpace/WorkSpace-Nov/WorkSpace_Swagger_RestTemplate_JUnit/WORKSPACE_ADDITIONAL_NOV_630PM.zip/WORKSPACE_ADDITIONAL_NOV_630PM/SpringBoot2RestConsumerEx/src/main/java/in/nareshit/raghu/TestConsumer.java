package in.nareshit.raghu;

import org.springframework.boot.CommandLineRunner;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import lombok.extern.slf4j.Slf4j;

//@Component
@Slf4j
public class TestConsumer implements CommandLineRunner{

	public void run(String... args) throws Exception {
		//a. Create Object to RestTemplate manually
		RestTemplate rt = new RestTemplate();
		
		//b. Define one URL of Producer Resource
		String url = "http://localhost:8080/student/show/{id}";
		
		//c. Make HTTP Request using httpMethod	  and pass all inputs required.
		//d. Read Response at same time
		ResponseEntity<String> response= 
				//rt.getForEntity(url, String.class,101);
				//URL, HttpMethod, HttpEntity(request), Class<T> responseType,
				rt.exchange(url, HttpMethod.GET, null, String.class, 101);
		
		//e. print/use details.
		log.info("Response body : {}", response.getBody());
		log.info("Response Status CODE : {}", response.getStatusCode().name());
		log.info("Response Status VALUE: {}", response.getStatusCodeValue());
		log.info("Response HEADERS: {}", response.getHeaders());
		
		//stop server before running one more time
		System.exit(0);
	}
}
