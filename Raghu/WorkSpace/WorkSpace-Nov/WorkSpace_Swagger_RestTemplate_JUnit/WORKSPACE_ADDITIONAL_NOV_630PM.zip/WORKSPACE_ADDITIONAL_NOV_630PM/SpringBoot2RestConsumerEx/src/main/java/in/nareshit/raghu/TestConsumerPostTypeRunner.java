package in.nareshit.raghu;

import org.springframework.boot.CommandLineRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import lombok.extern.slf4j.Slf4j;

//@Component
@Slf4j
public class TestConsumerPostTypeRunner implements CommandLineRunner {

	public void run(String... args) throws Exception {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		
		String body = "{\"sid\":10,\"sname\":\"A\",\"sfee\":200.0}";
		
		HttpEntity<String> request = new HttpEntity<String>(body, headers);
		
		
		RestTemplate rt = new RestTemplate();
		String url = "http://localhost:8080/student/save";

		// URL, Request, ResponseType, uriVariables
		ResponseEntity<String> resp = 
				//rt.postForEntity(url, request, String.class);
				//URL, HttpMethod, HttpEntity, ResponseType, uri variable
				rt.exchange(url, HttpMethod.POST, request, String.class);
		
		log.info("Body {}", resp.getBody());
		log.info("Code {}", resp.getStatusCode().name());
		log.info("value {}", resp.getStatusCode().value());
		log.info("Header {}", resp.getHeaders());
		
	}

}
