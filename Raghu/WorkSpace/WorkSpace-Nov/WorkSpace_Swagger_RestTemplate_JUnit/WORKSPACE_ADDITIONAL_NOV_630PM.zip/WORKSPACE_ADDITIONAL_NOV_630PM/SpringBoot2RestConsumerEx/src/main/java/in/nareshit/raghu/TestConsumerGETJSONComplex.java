package in.nareshit.raghu;

import java.util.Arrays;
import java.util.List;

import org.springframework.boot.CommandLineRunner;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import in.nareshit.raghu.model.Student;
import lombok.extern.slf4j.Slf4j;

//@Component
@Slf4j
public class TestConsumerGETJSONComplex implements CommandLineRunner{

	public void run(String... args) throws Exception {
		RestTemplate rt = new RestTemplate();
		
		String url = "http://localhost:8080/student/all";
		
		ResponseEntity<Student[]> response= 
				//rt.exchange(url, HttpMethod.GET, null, String.class, 101);
				rt.exchange(url, HttpMethod.GET, null, Student[].class, 101);
		
		List<Student> list = Arrays.asList(response.getBody());
		//e. print/use details.
		log.info("Response body : {}", list);
		log.info("Response Status CODE : {}", response.getStatusCode().name());
		log.info("Response Status VALUE: {}", response.getStatusCodeValue());
		log.info("Response HEADERS: {}", response.getHeaders());
		
		//stop server before running one more time
		System.exit(0);
	}
}
