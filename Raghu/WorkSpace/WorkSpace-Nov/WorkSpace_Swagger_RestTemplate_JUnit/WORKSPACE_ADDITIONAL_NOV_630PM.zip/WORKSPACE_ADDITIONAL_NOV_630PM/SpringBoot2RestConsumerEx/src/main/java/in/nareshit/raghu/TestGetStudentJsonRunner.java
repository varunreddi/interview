package in.nareshit.raghu;

import org.springframework.boot.CommandLineRunner;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import in.nareshit.raghu.model.Student;
import lombok.extern.slf4j.Slf4j;

//@Component
@Slf4j
public class TestGetStudentJsonRunner implements CommandLineRunner {

	public void run(String... args) throws Exception {
		RestTemplate rt = new RestTemplate();
		
		String url = "http://localhost:8080/student/find/{id}";
		
		ResponseEntity<Student> resp = 
				//rt.getForEntity(url, Student.class, 9025);
				//URL, HttpMethod, HttpEntity, Response type, URI Variables
				rt.exchange(url, HttpMethod.GET, null, Student.class, 500);
		
		log.info("Body {}", resp.getBody());
		log.info("Code {}", resp.getStatusCode().name());
		log.info("value {}", resp.getStatusCode().value());
		log.info("Header {}", resp.getHeaders());
		System.exit(0);
	}

}
