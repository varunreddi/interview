package in.nareshit.raghu;

import org.springframework.boot.CommandLineRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class TestConsumerPostTypeComplexRunner implements CommandLineRunner {

	public void run(String... args) throws Exception {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		
		String body = "[{\"sid\":10,\"sname\":\"A\",\"sfee\":200.0},{\"sid\":20,\"sname\":\"B\",\"sfee\":300.0},{\"sid\":30,\"sname\":\"C\",\"sfee\":400.0}]";
		
		HttpEntity<String> request = new HttpEntity<String>(body, headers);
		
		
		RestTemplate rt = new RestTemplate();
		String url = "http://localhost:8080/student/saveAll";

		ResponseEntity<String> resp = 
				rt.exchange(url, HttpMethod.POST, request, String.class);
		
		log.info("Body {}", resp.getBody());
		log.info("Code {}", resp.getStatusCode().name());
		log.info("value {}", resp.getStatusCode().value());
		log.info("Header {}", resp.getHeaders());
		
	}

}
