package in.nareshit.raghu.runner;

import org.springframework.boot.CommandLineRunner;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import lombok.extern.slf4j.Slf4j;

//@Component
@Slf4j
public class TestDeleteRunner implements CommandLineRunner {

	public void run(String... args) throws Exception {

		RestTemplate rt = new RestTemplate();
		String url = "http://localhost:8080/student/remove/{id}";
		
		//rt.delete(url, 101); //returns void
		//we can not get response given by producer here
		//log.info("DELETE IS CALLED SUCCESSFULLY");
		
		ResponseEntity<String> resp = rt.exchange(url, HttpMethod.DELETE, null, String.class, 999);
		
		log.info("Body {}", resp.getBody());
		log.info("Code {}", resp.getStatusCode().name());
		log.info("value {}", resp.getStatusCode().value());
		log.info("Header {}", resp.getHeaders());
	
		System.exit(0);
	}

}
