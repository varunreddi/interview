package in.nareshit.raghu.rest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/product")
public class ProductRestController {

	@GetMapping("/test/{code}")
	public String getDataA(
			@PathVariable String code
			) 
	{
		return "Data is " + code;
	}
	
	@GetMapping("/test/{name}")
	public String getDataB(
			@PathVariable String name
			) 
	{
		return "Data is => " + name;
	}
	
	
	/**
	 * /{key} and @PathVariable DataType key
	 * Here Path must be matching
	 */
	@GetMapping("/fetch/{code}")
	public String getOneProductB(
			@PathVariable String code
			) 
	{
		return "Data is => " + code;
	}
	/**
	 * Must pass id and code in same order
	 */
	@GetMapping("/get/{id}/{code}")
	public String getDescProduct(
			@PathVariable Integer id,
			@PathVariable String code
			) 
	{
		return "FIND => "+ id +"-"+code;
	}
}
