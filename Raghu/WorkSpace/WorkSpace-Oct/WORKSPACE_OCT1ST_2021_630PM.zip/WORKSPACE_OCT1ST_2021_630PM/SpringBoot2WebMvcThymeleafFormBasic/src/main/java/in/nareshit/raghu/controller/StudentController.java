package in.nareshit.raghu.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import in.nareshit.raghu.model.Student;

@Controller
@RequestMapping("/student")
public class StudentController {

	@GetMapping("/edit")
	public String showEditForm(
			Model model
			) 
	{
		Student sob = new Student(9999,"AA",200.0);
		model.addAttribute("student", sob);
		return "StudentEdit";
	}
	
	@PostMapping("/update")
	public String updateData(
			@ModelAttribute Student student,
			Model model
			) 
	{
		System.out.println(student);
		model.addAttribute("sob", student);
		return "StudentInfo";
	}
	
}
