package in.nareshit.raghu.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.nareshit.raghu.entity.Product;
import in.nareshit.raghu.exception.ProductNotFoundException;
import in.nareshit.raghu.repo.ProductRepository;
import in.nareshit.raghu.service.IProductService;

@Service
public class ProductServiceImpl implements IProductService {
	
	@Autowired
	private ProductRepository repo;

	public Integer saveProduct(Product p) {
		/*p = repo.save(p);
		Integer id = p.getProdId();
		return id;*/
		return repo.save(p).getProdId();
	}

	public Product findOneProduct(Integer id) {
		/*Optional<Product> opt = repo.findById(id);
		if(opt.isPresent()) {
			return opt.get();
		} else {
			throw new ProductNotFoundException(id+ " - not found");
		}*/
		return repo.findById(id).orElseThrow(
				()->new ProductNotFoundException(id+ " - not found")
				);
	}

	public List<Product> findAllProducts() {
		return repo.findAll();
	}

	public void deleteProduct(Integer id) {
		repo.delete(findOneProduct(id));
	}
	/**
	 * If given ID should not be null and ID exist in DB
	 * then update
	 */
	public void updateProduct(Product p) {
		if(null==p.getProdId() || !repo.existsById(p.getProdId())) {
			throw new ProductNotFoundException(p.getProdId()+ " - not found");
		} else {
			repo.save(p);
		}
	}

}
