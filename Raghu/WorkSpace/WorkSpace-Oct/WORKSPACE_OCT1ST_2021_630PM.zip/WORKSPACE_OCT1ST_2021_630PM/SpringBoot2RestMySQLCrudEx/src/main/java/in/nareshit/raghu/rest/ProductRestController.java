package in.nareshit.raghu.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.nareshit.raghu.entity.Product;
import in.nareshit.raghu.exception.ProductNotFoundException;
import in.nareshit.raghu.service.IProductService;

@RestController
@RequestMapping("/product")
public class ProductRestController {
	
	//private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(ProductRestController.class);
	
	@Autowired
	private IProductService service;

	//1. create product
	@PostMapping("/save")
	public ResponseEntity<String> createProduct(
			@RequestBody Product product) 
	{
		ResponseEntity<String> resp = null;
		Integer id = service.saveProduct(product);
		resp = new ResponseEntity<String>(
				"Product '"+id+"' created",
				HttpStatus.CREATED);
		return resp;
	}
	
	//2. view all products
	@GetMapping("/all")
	public ResponseEntity<List<Product>> getAllProducts() {
		ResponseEntity<List<Product>> resp = null;
		List<Product> list = service.findAllProducts();
		resp = new ResponseEntity<List<Product>>(list, HttpStatus.OK);
		return resp;
	}
	
	//3. find one product by id
	@GetMapping("/find/{id}")
	public ResponseEntity<?> fetchOneProduct(
			@PathVariable Integer id
			)
	{
		ResponseEntity<?> resp = null;
		try {
			Product p = service.findOneProduct(id);
			resp = new ResponseEntity<Product>(p, HttpStatus.OK);
			
		} catch (ProductNotFoundException e) {
			e.printStackTrace();
			throw e;
			/*resp = new ResponseEntity<String>(
					e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);*/
		}
		return resp;
	}
	
	//4. delete one product
	@DeleteMapping("/remove/{id}")
	public ResponseEntity<String> removeOneProduct(
			@PathVariable Integer id
			) 
	{
		ResponseEntity<String> resp = null;
		try {

			service.deleteProduct(id);
			resp = new ResponseEntity<String>(id+"-deleted!", HttpStatus.OK);
			
		} catch (ProductNotFoundException e) {
			e.printStackTrace();
			throw e;
			/*resp = new ResponseEntity<String>(
					e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);*/
		}
		return resp;
	}
	
	//5. update one product
	@PutMapping("/modify")
	public ResponseEntity<String> updateProduct(
			@RequestBody Product product) 
	{
		ResponseEntity<String> resp = null;
		try {
			service.updateProduct(product);
			resp = new ResponseEntity<String>(
					"Product updated!", 
					HttpStatus.OK);
		} catch (ProductNotFoundException e) {
			e.printStackTrace();
			throw e;
		}
		return resp;
	}
	
	//6. partial update (product code)
}
