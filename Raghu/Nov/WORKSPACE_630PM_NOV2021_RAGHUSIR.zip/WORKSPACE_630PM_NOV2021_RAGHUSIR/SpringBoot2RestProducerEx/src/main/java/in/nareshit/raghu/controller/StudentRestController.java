package in.nareshit.raghu.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.nareshit.raghu.model.Student;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/student")
@Slf4j
public class StudentRestController {
	
	//private static final Logger log = LoggerFactory.getLogger(StudentRestController.class);
	
	@GetMapping("/show/{id}")
	public ResponseEntity<String> showMsg(
			@PathVariable Integer id
			) 
	{
		return new ResponseEntity<String>(
				"DATA FOUND FOR ID :" + id,HttpStatus.OK);
	}
	
	@GetMapping("/all")
	public ResponseEntity<List<Student>> findAll() 
	{
		return new ResponseEntity<List<Student>>(
				Arrays.asList(
				new Student(101, "AJAY", 300.0),
				new Student(102, "SAM", 400.0),
				new Student(103, "SYED", 500.0)
				),
				HttpStatus.OK);
	}
	
	
	@GetMapping("/find/{id}")
	public ResponseEntity<Student> findOne(
			@PathVariable Integer id
			) 
	{
		return new ResponseEntity<Student>(
				new Student(id, "AJAY", 300.0),
				HttpStatus.OK);
	}
	
	@PostMapping("/save")
	public ResponseEntity<String> saveStd(
			@RequestBody Student student
			) 
	{
		return new ResponseEntity<String>(
				"Student saved => " + student,
				HttpStatus.CREATED);
	}
	
	@PostMapping("/saveAll")
	public ResponseEntity<String> saveMultiple(
			@RequestBody List<Student> student
			) 
	{
		return new ResponseEntity<String>(
				"Students saved multiple => " + student,
				HttpStatus.CREATED);
	}
	
	@DeleteMapping("/remove/{id}")
	public ResponseEntity<String> removeStudent(
			@PathVariable Integer id
			) 
	{
		log.info("DELETE METHOD IS CALLED WITH INPUT {}",id);
		return new ResponseEntity<String>(
				"Product removed=>"+id,
				HttpStatus.OK);
	}
	
	@PutMapping("/modify")
	public ResponseEntity<String> modifyStudent(
			@RequestBody Student student
			) 
	{
		log.info("PUT METHOD IS CALLED WITH INPUT: {}",student);
		return new ResponseEntity<String>(
				"Modified Data is  => " + student.toString(), 
				HttpStatus.OK);
	}
	
}
