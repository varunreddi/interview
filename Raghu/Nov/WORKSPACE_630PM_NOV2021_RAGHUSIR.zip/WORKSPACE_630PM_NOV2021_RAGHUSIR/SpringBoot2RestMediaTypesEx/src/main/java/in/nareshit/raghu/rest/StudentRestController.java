package in.nareshit.raghu.rest;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.nareshit.raghu.model.Exam;
import in.nareshit.raghu.model.ExamResult;
import in.nareshit.raghu.model.Student;

@RestController
@RequestMapping("/student")
public class StudentRestController {

	@GetMapping("/fetch")
	public Student findOneStudent() {
		return new Student(101,"AA", 200.0);
	}
	
	@GetMapping("/all")
	public List<Student> findAllStudent() {
		return Arrays.asList(
				new Student(101,"AA", 200.0),
				new Student(102,"BB", 300.0),
				new Student(103,"CC", 400.0),
				new Student(104,"DD", 500.0)
				);
	}
	
	@GetMapping("/result")
	public ExamResult getStudentResult() {
		return new ExamResult(
				550, "PASS", "A+", 360, 
				Arrays.asList(
							new Exam("MATHS", "PASS", 80),
							new Exam("SCIENCE", "PASS", 90),
							new Exam("CHEM", "PASS", 100),
							new Exam("BOI", "PASS", 90)
						), 
				new Student(98601, "AJAY KUMAR", 200.0)
				);
	}
	
	@GetMapping("/info")
	public Map<String,Student> getAllStudentsByCodes() {
		return Map.of(
					"SA-001-51200-TY",new Student(101,"AA", 100.0),
					"SA-001-51201-TR",new Student(102,"BB", 300.0),
					"SA-001-51202-TE",new Student(103,"CC", 400.0)
				);
	}
	
}
