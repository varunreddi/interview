package in.nareshit.raghu.runner;

import org.springframework.boot.CommandLineRunner;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import lombok.extern.slf4j.Slf4j;

//@Component
@Slf4j
public class TestHttpGetExchangeCallRunner implements CommandLineRunner {

	public void run(String... args) throws Exception {

		//1. Create RestTemplate class object
		RestTemplate rt = new RestTemplate();
		
		//2. Create URL for Producer
		String url = "http://localhost:8080/employee/msg/{id}";
		
		//3. Make Request CALL and get Response
		// URL, Http Method, RequestEntity, ResponseType, PathVariables
		ResponseEntity<String> response = rt.exchange(url, HttpMethod.GET, null, String.class, 360); 
		
		//4. Print Response details
		log.info("Response Body     : {}",response.getBody());
		log.info("Response code-val : {}",response.getStatusCodeValue());
		log.info("Response code-name: {}",response.getStatusCode().name());
		log.info("Response Headers  : {}",response.getHeaders());
		
		//5. Stop server
		System.exit(0);
	}

}
