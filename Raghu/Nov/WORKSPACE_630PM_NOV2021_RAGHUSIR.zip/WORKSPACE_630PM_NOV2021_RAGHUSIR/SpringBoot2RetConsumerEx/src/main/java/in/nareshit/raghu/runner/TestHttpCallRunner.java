package in.nareshit.raghu.runner;

import org.springframework.boot.CommandLineRunner;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import lombok.extern.slf4j.Slf4j;

//@Component
@Slf4j
public class TestHttpCallRunner implements CommandLineRunner {

	public void run(String... args) throws Exception {

		//1. Create RestTemplate class object
		RestTemplate rt = new RestTemplate();
		
		//2. Create URL for Producer
		String url = "http://localhost:8080/employee/msg/{id}";
		
		//3. Make Request CALL and get Response
		// URL, ResponseType, PathVariables(Object...)
		ResponseEntity<String> response = rt.getForEntity(url, String.class,990); 
		
		//4. Print Response details
		log.info("Response Body     : {}",response.getBody());
		log.info("Response code-val : {}",response.getStatusCodeValue());
		log.info("Response code-name: {}",response.getStatusCode().name());
		log.info("Response Headers  : {}",response.getHeaders());
		
		//5. Stop server
		System.exit(0);
	}

}
