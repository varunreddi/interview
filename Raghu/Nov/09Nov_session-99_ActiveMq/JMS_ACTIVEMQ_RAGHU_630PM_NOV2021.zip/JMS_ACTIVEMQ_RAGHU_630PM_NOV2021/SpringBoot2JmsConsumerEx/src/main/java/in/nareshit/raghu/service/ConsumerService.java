package in.nareshit.raghu.service;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class ConsumerService {

	@JmsListener(destination = "${my.desti.name}")
	public void readMessage(String message) {
		System.out.println("At Consumer#1 " + message);
	}
}
