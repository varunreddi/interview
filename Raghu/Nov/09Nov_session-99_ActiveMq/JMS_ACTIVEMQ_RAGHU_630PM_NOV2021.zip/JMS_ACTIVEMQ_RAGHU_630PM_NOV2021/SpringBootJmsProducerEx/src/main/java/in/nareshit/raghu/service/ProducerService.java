package in.nareshit.raghu.service;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ProducerService {

	@Value("${my.desti.name}")
	private String destination;
	
	@Autowired
	private JmsTemplate template;
	
	public boolean send(String message) {
		boolean sent = false;
		try {
			//destination,MessageCreator (using Lambda)
			/*template.send(
					destination, 
					session-> session.createTextMessage(message)
					);*/
			//Anonymous
			template.send(destination,new MessageCreator() {
				public Message createMessage(Session session) throws JMSException {
					TextMessage tm = session.createTextMessage(message);
					return tm;
				}
			} );
			log.info("MESSAGE SENT FROM PRODUCER ==> {}", message);
			sent = true;
		} catch (Exception e) {
			e.printStackTrace();
			sent = false;
			log.error("MESSAGE SENDING FAILED..");
		}
		return sent;
	}
}
