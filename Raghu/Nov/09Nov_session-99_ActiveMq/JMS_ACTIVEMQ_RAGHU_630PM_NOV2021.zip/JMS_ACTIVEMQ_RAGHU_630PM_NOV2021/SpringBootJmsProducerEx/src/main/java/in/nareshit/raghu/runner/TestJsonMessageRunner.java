package in.nareshit.raghu.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

import in.nareshit.raghu.model.ProductInfo;
import in.nareshit.raghu.service.ProducerService;

@Component
public class TestJsonMessageRunner 
//implements CommandLineRunner 
{

	@Autowired
	private ProducerService service;
	
	//public void run(String... args) throws Exception {
	@Scheduled(fixedDelay = 3000)
	public void run() throws Exception {
		ProductInfo pinfo = new ProductInfo("TEST-HYD","NIT");
		//Object --> JSON
		String data = new ObjectMapper().writeValueAsString(pinfo);
		service.send(data);
	}

}
