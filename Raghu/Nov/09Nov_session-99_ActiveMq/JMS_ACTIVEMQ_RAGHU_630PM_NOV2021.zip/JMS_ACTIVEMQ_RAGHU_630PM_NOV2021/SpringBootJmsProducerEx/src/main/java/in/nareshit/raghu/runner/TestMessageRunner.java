package in.nareshit.raghu.runner;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import in.nareshit.raghu.service.ProducerService;

//@Component
public class TestMessageRunner 
//implements CommandLineRunner 
{

	@Autowired
	private ProducerService service;
	
	//public void run(String... args) throws Exception {
	@Scheduled(fixedDelay = 3000)
	public void run() throws Exception {
		service.send("HELLO ="+ new Date());
	}

}
