# SpringBoot2SecurityJwtAp
Spring Boot + Data JPA + MySQL + Java JWT Security App <br/>
This application is implemented using Spring boot and JWT with MySQL Database
