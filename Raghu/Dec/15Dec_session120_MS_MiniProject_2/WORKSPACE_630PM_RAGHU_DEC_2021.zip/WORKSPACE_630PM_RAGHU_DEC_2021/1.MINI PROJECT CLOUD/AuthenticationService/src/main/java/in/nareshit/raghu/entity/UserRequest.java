package in.nareshit.raghu.entity;

import lombok.Data;

@Data
public class UserRequest {

	private String username;
	private String password;
}
