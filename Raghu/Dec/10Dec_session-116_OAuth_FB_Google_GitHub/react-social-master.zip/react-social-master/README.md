# Spring Boot & ReactJs OAuth FrontEnd App
## Hello This is done for Social Login using ReactJS and Spring Boot Testing 

### For Google
https://console.cloud.google.com/

http://localhost:8081 
http://localhost:8081/oauth2/callback/google

### For FB:
https://developers.facebook.com/

https://www.facebook.com/settings?tab=applications&ref=settings
---------------------------------------------------------------------------

### For Github
https://github.com/settings/developers

http://localhost:8081
http://localhost:8081

----------------------------------------------------------------------
//Step 1: 
npm install

//Step 2:
npm start
