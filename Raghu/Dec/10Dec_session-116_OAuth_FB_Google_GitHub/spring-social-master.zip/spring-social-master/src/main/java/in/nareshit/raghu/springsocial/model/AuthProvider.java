package in.nareshit.raghu.springsocial.model;

public enum  AuthProvider {
    local,
    facebook,
    google,
    github
}
